<?php

namespace App\Http\Controllers;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
//use App\Http\Models\SampleModel;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use App\Http\Models\TestModel;




class TestController extends Controller
{
    
    protected $testmodel;
	 
	public function __construct(TestModel $testmodel)
	{
		$this->testmodel = $testmodel;
	}
    public function circle() {
      
      $input = Input::all();
      $validator = Validator::make($input, [
            'radius' => 'required',
       ]);
      
      if ($validator->fails())
        {
            return response()->json(array("message" => $validator->messages()->first()),200);
        }
        
        else{
             $result = $this->testmodel->getcircle($input);
            
            if(count($result)>0){
                    return response()->json(array("circle" => $result),200);
            }
            else{
                    return response()->json(array("message" => "error occurred"),200);
            }
        }

   }
   
    public function triangle() {
      
      $input = Input::all();
      $validator = Validator::make($input, [
            'a' => 'required',
            'b' => 'required',
            'c' => 'required',
        ]);
      
      if ($validator->fails())
        {
            return response()->json(array("message" => $validator->messages()->first()),200);
        }
        
        else{
           
            $result = $this->testmodel->gettriangle($input);
            
            if(count($result)>0){
                    return response()->json(array("triangle" => $result),200);
            }
            else{
                    return response()->json(array("message" => "error occurred"),200);
            }
        }

   }
    
}
