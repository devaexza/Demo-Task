<?php namespace App\Http\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
class TestModel extends Model {
	protected $table = '';
	
	function getcircle($data){
		$radius = $data['radius'];
		$area = (3.14 * ($radius* $radius));
                $perimeter = (2 * 3.14 * $radius);
                $result = array('area'=> $area,
                            'perimeter'=> $perimeter);
		return $result;	
	}
        
       
        function gettriangle($data){
		$a = $data['a'];
		$b = $data['b'];
		$c = $data['c'];
                $perimeter = ($a + $b + $c);
                $p = (($perimeter)/2);
                $temp = ($p*($p-$a)*($p-$b)*($p-$c));
                if($temp < 0){
                    $result = array('area'=> $temp,
                            'perimeter'=> $perimeter); 
                    return $result;
                }
                $area = sqrt($temp);
                $result = array('area'=> $area,
                            'perimeter'=> $perimeter);
		return $result;	
	}
        
       
}