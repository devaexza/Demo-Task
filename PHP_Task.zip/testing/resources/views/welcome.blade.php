<!DOCTYPE html>
<html>
    <head>
        <title>Test</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!--        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">-->
        <link rel="stylesheet" href="resources/assets/css/bootstrap.min.css">

<!--        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>-->

        <script src="resources/assets/js/jquery.js"></script>
        <script src="resources/assets/js/bootstrap.min.js"></script>
<!--        <script src="resources/assets/js/knockout-3.4.2.js"></script>-->

        <script src="https://cdnjs.cloudflare.com/ajax/libs/knockout/3.4.2/knockout-min.js"></script>
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-6 col-sm-12 col-xs-12">
                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12" style="margin-top: 50px">
                        <h2>CIRCLE</h2>
                        <img src="resources/assets/images/circle.png" style="height: 100px">
                        <div class="form-group">
                            <label for="usr">Enter the radius(cm):</label>
                            <input  type="number" min="0"  maxlength="10" class="form-control numbersonly"  placeholder="Enter radius in cm" data-bind="value: radius">
                            <button class="btn btn-success" style="margin-right: 5px; margin-top: 10px" data-bind="click: calcircle "> Calculate </button>
                            <p style="font-size: 15px;font-weight: bold;margin-top: 10px">
                                Area of Circle : <span data-bind="text: areacircle"></span> cm<br>
                                Circumference of Circle : <span data-bind="text: perimetercircle"></span> cm
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12" style="margin-top: 50px">
                        <h2>TRIANGLE</h2>
                        <img src="resources/assets/images/triangle.png" style="height: 100px">
                        <div class="form-group">
                            <label>Triangle Side AB(cm):</label>
                            <input type="number"  min="0"  maxlength="10" class="form-control numbersonly" style="display: inline" data-bind="value: a"><br>
                            <label>Triangle Side BC(cm):</label>
                            <input type="number"  min="0"  maxlength="10" class="form-control numbersonly" style="display: inline" data-bind="value : b"><br>
                            <label>Triangle Side CA(cm):</label>
                            <input type="number"  min="0"  maxlength="10" class="form-control numbersonly" style="display: inline" data-bind="value : c"><br>
                            <button class="btn btn-success" style="margin-right: 5px; margin-top: 10px" data-bind="click: caltriangle "> CALCULATE </button>
                            <p style="font-size: 15px;font-weight: bold;margin-top: 10px">
                                Area of Triangle : <span data-bind="text: areatriangle"></span> cm<br>
                                SurfaceArea of Triangle : <span data-bind="text: perimetertriangle"></span> cm
                            </p>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </body>

    <script>
        
       

        $(document).ready(function () {
            initknockout();
        });

        function initknockout() {
            var self = this;
            self.areaViewModel = ko.observable(new AreaViewModel);
            ko.applyBindings(self.areaViewModel);

        }

        function AreaViewModel() {
            var self = this;
            self.radius = ko.observable(0);
            self.areacircle = ko.observable(0);
            self.perimetercircle = ko.observable(0);
            self.areatriangle = ko.observable(0);
            self.perimetertriangle = ko.observable(0);
            self.a = ko.observable(0);
            self.b = ko.observable(0);
            self.c = ko.observable(0);
            self.calcircle = function () {
                getcircle();
            };
            self.caltriangle = function () {
                gettriangle();
            };
        }

        function getcircle() {
            var datavalues = {'radius' : areaViewModel().radius()};
            $.ajax({
                url:"circle",
                type:"POST",
                data: datavalues,
                success:function(result){
                   areaViewModel().areacircle(result.circle.area);
                   areaViewModel().perimetercircle(result.circle.perimeter);
                   
                }
            }).error(function(){});
           
        }
        
        function gettriangle() {
            var datavalues = {'a' : areaViewModel().a(),'b': areaViewModel().b(),'c': areaViewModel().c()};
            $.ajax({
                url:"triangle",
                type:"POST",
                data: datavalues,
                success:function(result){
                   if((result.triangle.area) < 0){
                       areaViewModel().areatriangle("sqrt(" +result.triangle.area + ")");
                   }
                   else{
                        areaViewModel().areatriangle(result.triangle.area);
                   }
                  
                   areaViewModel().perimetertriangle(result.triangle.perimeter);
                }
            }).error(function(){});
           
        }
        
//        document.getElementBy('numbersonly').addEventListener('keydown', function(e) {
//            var key   = e.keyCode ? e.keyCode : e.which;
//
//            if (!( [8, 9, 13, 27, 46, 110, 190].indexOf(key) !== -1 ||
//                 (key == 65 && ( e.ctrlKey || e.metaKey  ) ) || 
//                 (key >= 35 && key <= 40) ||
//                 (key >= 48 && key <= 57 && !(e.shiftKey || e.altKey)) ||
//                 (key >= 96 && key <= 105)
//               )) e.preventDefault();
//        });
        
        $(document).on('keydown','.numbersonly',function(e){
            var key   = e.keyCode ? e.keyCode : e.which;

            if (!( [8, 9, 13, 27, 46, 110, 190].indexOf(key) !== -1 ||
                 (key == 65 && ( e.ctrlKey || e.metaKey  ) ) || 
                 (key >= 35 && key <= 40) ||
                 (key >= 48 && key <= 57 && !(e.shiftKey || e.altKey)) ||
                 (key >= 96 && key <= 105)
               )) e.preventDefault(); 
        });




    </script>
</html>
