 <?php namespace App;

 use Illuminate\Database\Eloquent\Model;

 class Authentication extends Model {

   protected $table="test";

   public function test(){
    $query =  "select * from test";
    return $query[0];
   }

}