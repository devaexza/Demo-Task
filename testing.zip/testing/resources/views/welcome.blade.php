<!DOCTYPE html>
<html>
    <head>
        <title>Test</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/knockout/3.4.2/knockout-min.js"></script>
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-6 col-sm-6 col-xs-6">
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6" style="margin-top: 50px">
                        <h2>AREA OF CIRCLE</h2>
                        <div class="form-group">
                            <label for="usr">Enter the radius:</label>
                            <input type="number" class="form-control" data-bind="value: r1">
                            <button class="btn btn-success" style="margin-right: 5px; margin-top: 5px"> Area of circle: </button><span data-bind="text: areaforcir" style="font-size: 18px;font-weight: bold"></span>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6" style="margin-top: 50px">
                        <h2>AREA OF TRIANGLE</h2>
                        <div class="form-group">
                            <label for="usr">Enter the base:</label>
                            <input type="number" class="form-control"  data-bind="value: base ">
                            <label for="usr">Enter the height: </label>
                            <input type="number" class="form-control"  data-bind="value: height ">
                            <button class="btn btn-success" style="margin-right: 5px; margin-top: 5px"> Area of triangle: </button><span data-bind="text: areafortri" style="font-size: 18px;font-weight: bold"></span>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </body>

    <script>

        $(document).ready(function () {
            initknockout();
        });

        function initknockout() {
            var self = this;
            self.areaViewModel = ko.observable(new AreaViewModel);
            ko.applyBindings(self.areaViewModel);

        }

        function AreaViewModel() {
            var self = this;
            self.r1 = ko.observable(0);
            self.base = ko.observable(0);
            self.height = ko.observable(0);
            self.areaforcir = ko.computed(function () {
                var result = (3.14 * (self.r1() * self.r1()));
                return result;
            });
            self.areafortri = ko.computed(function () {
                var result = ((self.base() * self.height())/2);
                return result;
            });
        }
        
      


    </script>
</html>
